// Declaración de la estructura Articulo
struct Articulo {
    let nombre: String  // Propiedad nombre de tipo String
    var precio: Double  // Propiedad precio de tipo Double
    var stock: Int      // Propiedad stock de tipo Int
}

// Declaración de la variable articulos como un array de Articulo
var articulos = [
    Articulo(nombre: "Chamarras", precio: 2500, stock: 10),
    Articulo(nombre: "Vestidos", precio: 500, stock: 80),
    Articulo(nombre: "Pantalones", precio: 700, stock: 50),
    Articulo(nombre: "Abrigos", precio: 2000, stock: 8)
]

var opcionIngresada: String = "" // Variable para almacenar la opción ingresada
var cuenta: Double = 0           // Variable para almacenar el total a pagar

while opcionIngresada != "2" { // Mientras no se seleccione "Salir"
    // Mostrar el catálogo de artículos
    print("****** Bienvenido a su boutique Norma ******\n")

    // Mostrar la lista de productos de forma dinámica
    for (index, articulo) in articulos.enumerated() {
        print("Articulo \(index + 1): \(articulo.nombre)")
        print("Precio: \(articulo.precio)")
        print("Stock: \(articulo.stock)")
        print("--------------------")
    }

    // Mostrar opciones del menú
    print("\n1.- Comprar artículo")
    print("2.- Salir")
    print("Seleccione una opción:")
    opcionIngresada = readLine() ?? "" // Leer la entrada del usuario

    switch opcionIngresada {
    case "1": // Comprar artículo
        print("Ingrese el número del artículo deseado:")
        if let numeroArticulo = Int(readLine() ?? ""), numeroArticulo > 0, numeroArticulo <= articulos.count {
            let articuloSeleccionado = articulos[numeroArticulo - 1]

            print("Ingrese la cantidad de \(articuloSeleccionado.nombre) que desea comprar:")
            if let cantidadIngresada = Int(readLine() ?? ""), cantidadIngresada > 0 {
                if cantidadIngresada <= articuloSeleccionado.stock {
                    let total = Double(cantidadIngresada) * articuloSeleccionado.precio
                    cuenta += total
                    articulos[numeroArticulo - 1].stock -= cantidadIngresada
                    print("Compra realizada exitosamente.")
                    print("Total a pagar por esta compra: $\(total)")
                    print("Gracias por su compra. Le esperamos nuevamente.\n")
                    print("Presione Enter para regresar al menú principal.")
                    _ = readLine() // Pausa antes de volver al menú principal
                } else {
                    print("Lo sentimos, no hay suficiente stock para su pedido.\n")
                    print("Presione Enter para regresar al menú principal.")
                    _ = readLine() // Pausa antes de volver al menú principal
                }
            } else {
                print("Cantidad no válida. Presione Enter para intentar nuevamente.\n")
                _ = readLine() // Pausa antes de volver al menú principal
            }
        } else {
            print("Artículo no válido. Presione Enter para intentar nuevamente.\n")
            _ = readLine() // Pausa antes de volver al menú principal
        }
    case "2": // Salir
        print("Gracias por visitarnos.")
    default:
        print("Opción no válida. Presione Enter para intentar nuevamente.\n")
        _ = readLine() // Pausa antes de volver al menú principal
    }
}
