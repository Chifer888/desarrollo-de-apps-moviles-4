// 1.- Se crean las variables a utilizar

var aux: String = ""
var opcionIngresada: String = aux
// las dos primeras sirven para guardar los datos ingresados por el usuario
var saldoTotal: Double = 0.0 // sirve para mostrar el saldo total

// 2.- se crean las funciones para que el programa funcione
func deposito() {
  print("\n")
  print("Ingresa el monto a depositar: ")
  aux = readLine()!
  opcionIngresada = aux

// 3.- se crea la variable para que se sume al saldo total como Doule
let depositoIngresado = Double(opcionIngresada) ?? 0.0
  if depositoIngresado == 0.0 {
    print("Ingreso no valido")
  }else{
    print("Abono realizado con exito por $ \(depositoIngresado)")
  }
saldoTotal = saldoTotal + depositoIngresado
print("\n")  
}

// 4.- Se crea el menú interactivo que se mostrara al inicio utilizando la sentencia while
while opcionIngresada != "4" {
  print("** Bienvenido a su Banco Mexicano**")
  print("\n")
  print("Elija uina opción")
  print("\n")
  print("1.- Deposito")
  print("2.- Retiro")
  print("3.- Saldo")
  print("4.- Salir")

  aux = readLine()!
  opcionIngresada = aux

  // 5.- Se valida la opción ingresada por el usuario utilizando la sentencia switch
  switch opcionIngresada {
    case "1":
      deposito()
      print("\n")
      print("Desea realizar otro deposito? (S/N): ")
      aux = readLine()!
      opcionIngresada = aux

    // Se utiliza el metodo if para validar si es afirmativa la respuesta del usuario
        if opcionIngresada == "S" || opcionIngresada == "s" ||              opcionIngresada == "Si" || opcionIngresada == "si" ||            opcionIngresada == "SI" {
           deposito()
        }

    // Se utiliza el metodo if para validar si es negativa la respuesta del usuario

       if opcionIngresada == "N" || opcionIngresada == "n" ||              opcionIngresada == "No" || opcionIngresada == "no" ||            opcionIngresada == "NO" {
          print("\n")
          print("¿Desea realizar alguna otra operación? (S/N): ")
          aux = readLine()!
          opcionIngresada = aux

         if opcionIngresada == "N" || opcionIngresada == "n" ||           opcionIngresada == "No" || opcionIngresada == "no" ||            opcionIngresada == "NO"{
           print("\n")
           print("Sesión terminada, \ngracias por utilizar                  nuestra app.")
           opcionIngresada = "4"
         }
       }

    case "2":
      print("por el mmomento esta opciòn no esta disponible")

    case "3":
      print("por el mmomento esta opciòn no esta disponible")

    // Siempre que se utilice switch se debe utilizar la opción default para que el programa no se caiga 
    default:

    if opcionIngresada != "4"{
      print("\n")
      print("opcion no valida")
    } else {
    print("\n")
    print("Sesión terminada, \ngracias por utilizar nuestra app.")
    }
  }
}



